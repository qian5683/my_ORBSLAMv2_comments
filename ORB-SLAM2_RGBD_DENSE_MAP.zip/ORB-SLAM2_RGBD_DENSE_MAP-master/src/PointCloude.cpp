#include "PointCloude.h"
namespace ORB_SLAM2
{
PointCloude::PointCloude(){}


}
