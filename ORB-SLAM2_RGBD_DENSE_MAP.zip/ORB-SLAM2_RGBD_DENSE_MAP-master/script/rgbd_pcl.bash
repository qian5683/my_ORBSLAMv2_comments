#! /bin/bash
./bin/rgbd_tum Vocabulary/ORBvoc.bin Examples/RGB-D/TUM1.yaml ~/Downloads/rgbd_dataset_freiburg1_xyz/ Examples/RGB-D/associations/fr1_xyz.txt 
